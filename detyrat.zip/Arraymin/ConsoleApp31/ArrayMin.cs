﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp31
{

public class ArrayMin
    {
        private int[] array;

        public ArrayMin(int size)
        {
            array = new int[size];
        }

        public void FillArray()
        {
            Console.WriteLine("Ju lutem jepni vlerat e vargut:");

            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"Vlera {i + 1}: ");
                int value = Convert.ToInt32(Console.ReadLine());
                array[i] = value;
            }
        }

        public int Min()
        {
            int minValue = array[0];

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < minValue)
                {
                    minValue = array[i];
                }
            }

            return minValue;
        }
    }


}

