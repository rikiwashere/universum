﻿using ConsoleApp31;

public class Program
{
    public static void Main(string[] args)
    {
        Console.Write("Jepni madhësinë e vargut: ");
        int size = Convert.ToInt32(Console.ReadLine());

        ArrayMin myArray = new ArrayMin(size);
        myArray.FillArray();

        int minValue = myArray.Min();
        Console.WriteLine($"Vlera më e vogël në varg është: {minValue}");
    }
}