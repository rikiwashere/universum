﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp32
{
    internal class Menagjer : Employees
    {

        public override double CalculateBonus(double Rroga )
        {
            Bonusi_Fiks = 50000;
            Bonusi_Perqindja = Rroga * 0.25;
            return Math.Max(Bonusi_Fiks, Bonusi_Perqindja);
        }


    }
}
