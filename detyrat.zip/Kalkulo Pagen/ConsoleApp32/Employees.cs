﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp32
{
    internal class Employees
    {
        public int Id { get; set; }
        public string Emri { get; set; }
        public string Pozita { get; set; }
        public double Rroga { get; set; }
        public double Bonusi_Fiks { get; set; }
        public double Bonusi_Perqindja { get; set; }

        public virtual double CalculateBonus(double Rroga)
        {
            return Bonusi_Fiks;
        }

    }
}
