﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp32
{
    internal class Admin:Employees

    {
        public override double CalculateBonus(double Rroga)
        {
            return 50000;


        }
    }
}
