﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp32;
internal class Program
{
    static void Main(string[] args)
    {

        Admin Objekti_Admin = new Admin();
        Objekti_Admin.Id = 1;
        Objekti_Admin.Emri = " Riki ";
        Objekti_Admin.Pozita = "Admin";
        Objekti_Admin.Rroga = 10000;

         
        Zhvillues Objekti_zhvillues = new Zhvillues();
        Objekti_zhvillues.Id = 2;
        Objekti_zhvillues.Emri = "Faton";
        Objekti_zhvillues.Pozita = "Zhvillues";
        Objekti_zhvillues.Rroga = 20000;

        
        Menagjer Objekti_Menagjer = new Menagjer();
        Objekti_Menagjer.Id = 3;
        Objekti_Menagjer.Emri = "Gezim";
        Objekti_Menagjer.Pozita = "Menagjer";
        Objekti_Menagjer.Rroga = 1000000;


        Console.WriteLine("------------------------------------------");





        Console.WriteLine("Detajet e Punonjësit (Admin):");
        Console.WriteLine($"ID: {Objekti_Admin.Id}");
        Console.WriteLine($"Emri: {Objekti_Admin.Emri}");
        Console.WriteLine($"Pozita: {Objekti_Admin.Pozita}");
        Console.WriteLine($"Rroga: {Objekti_Admin.Rroga}");
        Console.WriteLine($"Bonusi: {Objekti_Admin.CalculateBonus(Objekti_Admin.Rroga)}");

        Console.WriteLine("------------------------------------------");




        Console.WriteLine("Detajet e Punonjësit (Zhvilluesi):");
        Console.WriteLine($"ID: {Objekti_zhvillues.Id}");
        Console.WriteLine($"Emri: {Objekti_zhvillues.Emri}");
        Console.WriteLine($"Pozita: {Objekti_zhvillues.Pozita}");
        Console.WriteLine($"Rroga: {Objekti_zhvillues.Rroga}");
        Console.WriteLine($"Bonusi: {Objekti_zhvillues.CalculateBonus(Objekti_Admin.Rroga)}");


        Console.WriteLine("------------------------------------------");



        Console.WriteLine("Detajet e Punonjësit (Menagjer):");
        Console.WriteLine($"ID: {Objekti_Menagjer.Id}");
        Console.WriteLine($"Emri: {Objekti_Menagjer.Emri}");
        Console.WriteLine($"Pozita: {Objekti_Menagjer.Pozita}");
        Console.WriteLine($"Rroga: {Objekti_Menagjer.Rroga}");
        Console.WriteLine($"Bonusi: {Objekti_Menagjer.CalculateBonus(Objekti_Menagjer.Rroga)}");
        Console.ReadKey();




    }

}